
import java.util.LinkedHashMap;
import java.util.Map;

public class Cola {

    private LinkedHashMap<Integer,Boolean> nums;
    private final int  MAXSIZE = 5;
    private boolean isFull;
    private int sum; 
    private int mult;

    public Cola(){
        
        nums =new LinkedHashMap<>();
        isFull=false;
        sum = 0;
        mult = 1;

    }

    public synchronized void addNum(int id){
        
        while (isFull) {

            try {
                wait();
            } catch (InterruptedException e) {}
            
        }

        int rn = random(0, 100);

        nums.put(rn,false);

        notify();

        if (nums.size()==MAXSIZE) {
            isFull=true;
        }

        System.out.println("Productor: "+id+" he escrito: "+rn);
        
    }

    public synchronized void getNum(int id,boolean isSum){
        
        while (nums.isEmpty()) {
            try {
                notify();
                wait();
            } catch (InterruptedException e) {}
        }

        Map.Entry<Integer,Boolean> fe = nums.entrySet().iterator().next();

        int num = fe.getKey();
        boolean ar = fe.getValue();

        if (isSum) {
            
            sum += num;

            System.out.println("Consumidor: "+id+" he leido: "+num+" la suma es: "+sum);

        }else{

            mult *= num;

            System.out.println("Consumidor: "+id+" he leido: "+num+" la multiplicacion es: "+mult);
        }

        if (ar) {

            nums.remove(num);

        }else{

            nums.replace(num, true);

        }

        if (nums.size()!=MAXSIZE) {
            isFull=false;
        }

    }

    private static int random(int min, int max) {
        return (int) (Math.random() * (max - min + 1)) + min;
    }
    
}
